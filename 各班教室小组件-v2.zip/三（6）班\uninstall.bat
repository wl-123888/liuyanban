@echo off
chcp 65001 >nul
echo 正在卸载家长留言板小组件...

taskkill /f /im powershell.exe 2>nul

set "INSTALL_DIR=%USERPROFILE%\ParentBoard"
set "DESKTOP=%USERPROFILE%\Desktop"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

if exist "%DESKTOP%\家长留言板.lnk" del /q "%DESKTOP%\家长留言板.lnk"
if exist "%STARTUP%\家长留言板.lnk" del /q "%STARTUP%\家长留言板.lnk"
if exist "%INSTALL_DIR%" rd /s /q "%INSTALL_DIR%"

echo 卸载完成！
pause
