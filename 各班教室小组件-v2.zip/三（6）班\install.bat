@echo off
chcp 65001 >nul
set "INSTALL_DIR=%USERPROFILE%\ParentBoard"
set "SRC=%~dp0"

echo ============================================
echo   家长留言板 - 教室小组件 安装程序
echo ============================================
echo.
echo 安装目录: %INSTALL_DIR%
echo.

echo [1/3] 复制文件...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

copy /Y "%SRC%widget.ps1" "%INSTALL_DIR%\" >nul 2>&1 && echo   [OK] widget.ps1 || echo   [FAIL] widget.ps1
copy /Y "%SRC%launch-widget.vbs" "%INSTALL_DIR%\" >nul 2>&1 && echo   [OK] launch-widget.vbs || echo   [FAIL] launch-widget.vbs
copy /Y "%SRC%config.json" "%INSTALL_DIR%\" >nul 2>&1 && echo   [OK] config.json || echo   [FAIL] config.json
copy /Y "%SRC%uninstall.bat" "%INSTALL_DIR%\" >nul 2>&1 && echo   [OK] uninstall.bat || echo   [FAIL] uninstall.bat
if exist "%SRC%Microsoft.Web.WebView2.WinForms.dll" copy /Y "%SRC%Microsoft.Web.WebView2.WinForms.dll" "%INSTALL_DIR%\" >nul 2>&1 && echo   [OK] WebView2.WinForms.dll || echo   [FAIL] WebView2.WinForms.dll
if exist "%SRC%Microsoft.Web.WebView2.Core.dll" copy /Y "%SRC%Microsoft.Web.WebView2.Core.dll" "%INSTALL_DIR%\" >nul 2>&1 && echo   [OK] WebView2.Core.dll || echo   [FAIL] WebView2.Core.dll

echo.
echo [2/3] 创建快捷方式...

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell;$desk=[Environment]::GetFolderPath('Desktop');$sc=$ws.CreateShortcut($desk+'\家长留言板.lnk');$sc.TargetPath='%INSTALL_DIR%\launch-widget.vbs';$sc.WorkingDirectory='%INSTALL_DIR%';$sc.IconLocation='%SystemRoot%\System32\shell32.dll,14';$sc.Save();Write-Host '  [OK] 桌面快捷方式'"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell;$su=[Environment]::GetFolderPath('Startup');$sc=$ws.CreateShortcut($su+'\家长留言板.lnk');$sc.TargetPath='%INSTALL_DIR%\launch-widget.vbs';$sc.WorkingDirectory='%INSTALL_DIR%';$sc.Save();Write-Host '  [OK] 开机自启动'"

echo.
echo [3/3] 启动小组件...
start "" "%INSTALL_DIR%\launch-widget.vbs"

echo.
echo ============================================
echo   安装完成！
echo.
echo   桌面快捷方式: "家长留言板"
echo   开机自启动: 已启用
echo.
echo   修改班级: 编辑 %INSTALL_DIR%\config.json
echo   卸载: 双击 %INSTALL_DIR%\uninstall.bat
echo ============================================
pause
