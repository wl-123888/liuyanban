Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# === Read config ===
$configPath = Join-Path $scriptDir 'config.json'
$classCode = ''
if (Test-Path $configPath) {
    try {
        $config = Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $classCode = $config.class_code
    } catch {}
}
if (-not $classCode -or $classCode -match '请在此输入') {
    [System.Windows.Forms.MessageBox]::Show('请先编辑 config.json 中的班级名称', 'ParentBoard', 'OK', 'Information')
    exit 1
}

# === Load WebView2 ===
$wv2Dll = $null
$searchRoots = @(
    "$env:ProgramFiles\Microsoft\EdgeWebView\Application",
    "${env:ProgramFiles(x86)}\Microsoft\EdgeWebView\Application"
)
foreach ($root in $searchRoots) {
    if (-not (Test-Path $root)) { continue }
    $dll = Get-ChildItem $root -Recurse -Filter 'Microsoft.Web.WebView2.WinForms.dll' -ErrorAction SilentlyContinue |
           Where-Object { $_.FullName -notmatch 'SetupMetrics' } | Select-Object -First 1
    if ($dll) { $wv2Dll = $dll.FullName; break }
}
if (-not $wv2Dll) {
    $localDll = Join-Path $scriptDir 'Microsoft.Web.WebView2.WinForms.dll'
    if (Test-Path $localDll) { $wv2Dll = $localDll }
}
if (-not $wv2Dll) {
    [System.Windows.Forms.MessageBox]::Show('WebView2 not found. Please install Microsoft Edge.', 'ParentBoard', 'OK', 'Error')
    exit 1
}
Add-Type -Path $wv2Dll

# === Build HTML ===
$html = @"
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;background:#12121a;color:#e0e0e0;height:100vh;display:flex;flex-direction:column;overflow:hidden;user-select:none}
.hd{text-align:center;padding:14px 14px 10px;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0}
.hd .tl{font-size:16px;font-weight:700;color:#e8d44d;letter-spacing:2px}
.hd .info{font-size:10px;color:rgba(255,255,255,.3);margin-top:3px}
.area{flex:1;overflow-y:auto;padding:10px 12px}
.area::-webkit-scrollbar{width:3px}
.area::-webkit-scrollbar-thumb{background:rgba(255,255,255,.08);border-radius:2px}
.card{background:rgba(255,255,255,.04);border-radius:10px;padding:12px 14px;margin-bottom:8px;border-left:3px solid #e8d44d;animation:fadeIn .35s ease}
.card .txt{font-size:14px;line-height:1.6;word-break:break-all}
.card .t{font-size:10px;color:rgba(255,255,255,.25);margin-top:6px}
.emp{text-align:center;color:rgba(255,255,255,.18);font-size:13px;padding:32px 0}
@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>
<div class="hd">
  <div class="tl">$classCode</div>
  <div class="info" id="info">加载中...</div>
</div>
<div class="area" id="msgs"><div class="emp">加载中...</div></div>

<script>
var API='https://1437238162-ho33k071it.ap-guangzhou.tencentscf.com';
var CLASS='$classCode';
function isToday(d){return new Date(d).toDateString()===new Date().toDateString()}
function fmt(d){var dt=new Date(d),df=Date.now()-dt;if(df<6e4)return'刚刚';if(df<36e5)return Math.floor(df/6e4)+'分钟前';return dt.getHours().toString().padStart(2,'0')+':'+dt.getMinutes().toString().padStart(2,'0')}
function load(){
  fetch(API+'/api/messages?limit=200&class_code='+encodeURIComponent(CLASS)).then(function(r){return r.json()}).then(function(r){
    var ms=(r&&r.data)?r.data.filter(function(m){return m.class_code===CLASS&&isToday(m.createTime||m.time)}):[];
    document.getElementById('info').textContent='今日 '+ms.length+' 条';
    var a=document.getElementById('msgs');
    if(!ms.length){a.innerHTML='<div class="emp">暂无留言</div>';return}
    a.innerHTML=ms.reverse().map(function(m){return'<div class="card"><div class="txt">'+esc(m.content)+'</div><div class="t">'+fmt(m.createTime||m.time)+'</div></div>'}).join('');
    a.scrollTop=a.scrollHeight
  }).catch(function(){document.getElementById('msgs').innerHTML='<div class="emp">网络异常</div>'})
}
function esc(t){var d=document.createElement('div');d.textContent=t;return d.innerHTML}
load();setInterval(load,5e3);
</script>
</body>
</html>
"@

# === Create widget window ===
$screen = [System.Windows.Forms.Screen]::PrimaryScreen
[int]$widgetW = 340
[int]$widgetH = 500
[int]$posX = $screen.WorkingArea.Width - $widgetW - 16
[int]$posY = $screen.WorkingArea.Height - $widgetH - 50
[int]$closeX = $widgetW - 30

$form = New-Object System.Windows.Forms.Form
$form.Text = 'ParentBoard'
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
$form.ShowInTaskbar = $false
$form.Width = $widgetW
$form.Height = $widgetH
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
$form.Location = New-Object System.Drawing.Point($posX, $posY)
$form.BackColor = [System.Drawing.Color]::FromArgb(18, 18, 26)
$form.TopMost = $false
$form.ShowIcon = $false

$form.Add_Shown({
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    [int]$r = 16
    $path.AddArc(0, 0, $r*2, $r*2, 180, 90)
    $path.AddArc($form.Width - ($r*2), 0, $r*2, $r*2, 270, 90)
    $path.AddArc($form.Width - ($r*2), $form.Height - ($r*2), $r*2, $r*2, 0, 90)
    $path.AddArc(0, $form.Height - ($r*2), $r*2, $r*2, 90, 90)
    $path.CloseFigure()
    $form.Region = New-Object System.Drawing.Region($path)
})

# Title bar
$titleBar = New-Object System.Windows.Forms.Panel
$titleBar.Height = 26
$titleBar.Dock = [System.Windows.Forms.DockStyle]::Top
$titleBar.BackColor = [System.Drawing.Color]::FromArgb(24, 24, 34)

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "家长留言板 - $classCode"
$titleLabel.ForeColor = [System.Drawing.Color]::FromArgb(180, 180, 190)
$titleLabel.Location = New-Object System.Drawing.Point(10, 5)
$titleLabel.AutoSize = $true
$titleLabel.Font = New-Object System.Drawing.Font('Microsoft YaHei', 9)
$titleBar.Controls.Add($titleLabel)

$closeBtn = New-Object System.Windows.Forms.Label
$closeBtn.Text = 'X'
$closeBtn.ForeColor = [System.Drawing.Color]::FromArgb(140, 140, 150)
$closeBtn.Location = New-Object System.Drawing.Point($closeX, 2)
$closeBtn.Size = New-Object System.Drawing.Size(24, 22)
$closeBtn.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$closeBtn.Cursor = [System.Windows.Forms.Cursors]::Hand
$closeBtn.Add_Click({ $form.Close() })
$closeBtn.Add_MouseEnter({ $closeBtn.ForeColor = [System.Drawing.Color]::White })
$closeBtn.Add_MouseLeave({ $closeBtn.ForeColor = [System.Drawing.Color]::FromArgb(140, 140, 150) })
$titleBar.Controls.Add($closeBtn)

$form.Controls.Add($titleBar)

# Right-click menu on title bar
$titleMenu = New-Object System.Windows.Forms.ContextMenuStrip
$exitItem = New-Object System.Windows.Forms.ToolStripMenuItem('退出')
$exitItem.Add_Click({ $form.Close() })
$titleMenu.Items.Add($exitItem)
$titleBar.ContextMenuStrip = $titleMenu

# WebView2
$wv = New-Object Microsoft.Web.WebView2.WinForms.WebView2
$wv.Dock = [System.Windows.Forms.DockStyle]::Fill
$wv.CreationProperties = New-Object Microsoft.Web.WebView2.WinForms.CoreWebView2CreationProperties
$wv.CreationProperties.set_UserDataFolder((Join-Path $env:TEMP 'ParentBoardWV2'))
$form.Controls.Add($wv)

$wv.NavigateToString($html)

[System.Windows.Forms.Application]::Run($form)
if ($wv) { $wv.Dispose() }
$form.Dispose()
